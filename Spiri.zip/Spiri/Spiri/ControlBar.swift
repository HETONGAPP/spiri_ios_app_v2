//
//  ControlBar.swift
//  Spiri
//
//  Created by TongHe on 2021-03-15.
//

import UIKit
import Parse
import WebKit

class ControlBar: UIViewController, WKUIDelegate {

    let appDelegate: AppDelegate? = UIApplication.shared.delegate as? AppDelegate


    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .red
        
    }
    

}
