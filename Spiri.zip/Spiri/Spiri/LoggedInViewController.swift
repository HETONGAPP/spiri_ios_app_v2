//
//  LoggedInViewController.swift
//  AddingParseSDK
//
//  Created by TongHe on 2021-02-25.
//  Copyright © 2021 TongHe. All rights reserved.
//

import UIKit
import Parse
import NMSSH


class LoggedInViewController: UIViewController {
    let appDelegate: AppDelegate? = UIApplication.shared.delegate as? AppDelegate
    let session = NMSSHSession(host: "192.168.1.7", andUsername: "tong")
    

    @IBOutlet weak var imageView: UIButton!
    @IBOutlet weak var ImageButton: UIButton!
    
    func SSHConnection(_ command: String){
        session.connect()
        if session.isConnected == true{
            session.authenticate(byPassword: "tong")
            if session.isAuthorized == true {
                //print("works");
            }
            var error: NSError?
        
        //session.channel.execute("python3 GCS.py " + command, error: &error)
            let response: NSString! = session.channel.execute("python3 GCS.py " + command, error: &error) as NSString

            //session.channel.write("python3 GCS.py " + command, error: &error, timeout: 300)
            NSLog("List of my sites: %@", response)
            session.disconnect()
        }
    }
    func loadImageScreen(){
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let imageViewController = storyBoard.instantiateViewController(withIdentifier: "ImageViewController") as! ImageViewController
        self.present(imageViewController, animated: true, completion: nil)
    }

    //@IBAction func getImage(_ sender: Any) {
    //    loadImageScreen()
    //}

    override func viewDidLoad() {
        super.viewDidLoad()
        //self.ImageButton.isEnabled = false
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewDidAppear(_ animated: Bool) {
        appDelegate?.startPushNotifications()
    }
    
    @IBAction func takeOff(_ sender: UIButton) {
        SSHConnection("ARM_TAKEOFF")
    
    }
    @IBAction func land(_ sender: UIButton) {
        SSHConnection("LAND")
    
    }
    @IBAction func square(_ sender: UIButton) {
        SSHConnection("SQUARE")
    
    }
    @IBAction func circle(_ sender: UIButton) {
        SSHConnection("CIRCLE")
    
    }
    @IBAction func helix(_ sender: UIButton) {
        SSHConnection("HELIX")
    
    }
    @IBAction func lemniscate(_ sender: UIButton) {
        SSHConnection("LEMNISCATE")
    
    }
    @IBAction func followMe(_ sender: UIButton) {
        SSHConnection("FOLLOWME")
    
    }





    @IBAction func logoutOfApp(_ sender: UIButton) {
        let sv = UIViewController.displaySpinner(onView: self.view)
        PFUser.logOutInBackground { (error: Error?) in
            UIViewController.removeSpinner(spinner: sv)
            if (error == nil){
                self.loadLoginScreen()
            }else{
                if let descrip = error?.localizedDescription{
                    self.displayMessage(message: descrip)
                }else{
                    self.displayMessage(message: "error logging out")
                }

            }
        }
    }


    func displayMessage(message:String) {
        let alertView = UIAlertController(title: "Message", message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction) in
        }
        alertView.addAction(OKAction)
        if let presenter = alertView.popoverPresentationController {
            presenter.sourceView = self.view
            presenter.sourceRect = self.view.bounds
        }
        self.present(alertView, animated: true, completion:nil)
    }

    func loadLoginScreen(){
        //let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        //let viewController = storyBoard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        //self.present(viewController, animated: true, completion: nil)
        dismiss(animated: true, completion: nil)
    }


}



