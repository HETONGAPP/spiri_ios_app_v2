//
//  CommandPacket.m
//  Spiri
//
//  Created by TongHe on 2021-03-11.
//

#import "CommandPacket.h"

@implementation CommandPacketCreator

+ (NSData *)dataFrom:(CommanderPacket) packet {
    NSData *data = [NSData dataWithBytes:&packet length:sizeof(CommanderPacket)];
    //NSLog(@"%@", data);
    //30000000 00000000 80000000 000000 -> Default data package without any input
    return data;
}

@end
