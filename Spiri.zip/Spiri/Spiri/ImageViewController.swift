//
//  LoggedInViewController.swift
//  AddingParseSDK
//
//  Created by TongHe on 2021-02-25.
//  Copyright © 2021 TongHe. All rights reserved.
//

import UIKit
import Parse
import WebKit
import NMSSH
class ImageViewController: UIViewController, WKUIDelegate {
    let appDelegate: AppDelegate? = UIApplication.shared.delegate as? AppDelegate

    @IBOutlet weak var closeButton: UIButton!

    @IBOutlet weak var slidLabel2: UILabel!
    @IBOutlet weak var slidLabel1: UILabel!
    @IBOutlet weak var mySlider2: UISlider!
    @IBOutlet weak var mySlider: UISlider!
    @IBOutlet weak var TAKEOFF: UIButton!
    @IBOutlet weak var SQUARE: UIButton!
    @IBOutlet weak var LAND: UIButton!
    @IBOutlet weak var CIRCLE: UIButton!
    @IBOutlet weak var HELIX: UIButton!
    @IBOutlet weak var LEMNISCATE: UIButton!
    public var triggerValue = 0

    
    //let imageController = ImageController()
    enum Segues {
        static let imageController = "ImageController"
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        mySlider.transform = CGAffineTransform(rotationAngle: (CGFloat.pi / 2))
        mySlider2.transform = CGAffineTransform(rotationAngle: (CGFloat.pi / 2))
        slidLabel1.text = "gain"
        slidLabel2.text = "exposure"
        
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == Segues.imageController{
            _ = segue.destination as! ImageController
      
        }

    }
    
    let session = NMSSHSession(host: "192.168.1.7", andUsername: "tong")
    
    
    func SSHConnection(_ command: String, _ mode: Bool){
        session.connect()
        if session.isConnected == true{
            session.authenticate(byPassword: "tong")
            if session.isAuthorized == true {
                print("works");
            }
            var error: NSError?
            if mode == true{
                let ImageResponse: NSString! = session.channel.execute("v4l2-ctl -d /dev/video0 -c " + command, error: &error) as NSString
                NSLog("List of my sites: %@", ImageResponse)
            }else{
                let CommandResponse: NSString! = session.channel.execute("python3 GCS.py " + command, error: &error) as NSString
                NSLog("List of my sites: %@", CommandResponse)
                
            }

            session.disconnect()
            
            
        }
    }
    
    @IBAction func takeoff(_ sender: UIButton) {

        let queue1 = DispatchQueue(label: "com.appcoda.queue1", qos: DispatchQoS.utility)
        queue1.async {
            self.SSHConnection("ARM_TAKEOFF",false)
        }

        
    }
    
    @IBAction func land(_ sender: UIButton) {
        let queue2 = DispatchQueue(label: "com.appcoda.queue2", qos: DispatchQoS.userInitiated)
        queue2.async {
           self.SSHConnection("LAND",false)
        }
        
        
    }
    @IBAction func square(_ sender: UIButton) {
        let queue3 = DispatchQueue(label: "com.appcoda.queue3", qos: DispatchQoS.utility)
        queue3.async {
            self.SSHConnection("SQUARE",false)
            
        }
        
    
        
        
    }
    @IBAction func circle(_ sender: UIButton) {
        let queue4 = DispatchQueue(label: "com.appcoda.queue4", qos: DispatchQoS.utility)
        queue4.async {
            self.SSHConnection("CIRCLE",false)
        }
        
    }
 
    @IBAction func helix(_ sender: Any) {
        let queue5 = DispatchQueue(label: "com.appcoda.queue5", qos: DispatchQoS.utility)
        queue5.async {
            self.SSHConnection("HELIX",false)
        }
    }
    @IBAction func lemniscate(_ sender: UIButton) {
        let queue6 = DispatchQueue(label: "com.appcoda.queue6", qos: DispatchQoS.utility)
        queue6.async {
            self.SSHConnection("LEMNISCATE",false)
        }
    }
    
    
    
    
    @IBAction func sliding1(_ sender: Any) {
        let con1 = String(mySlider.value)
        slidLabel1.text = String(mySlider.value)
        print("gain="+con1)
        //SSHConnection("gain="+con1)
    }
    
    @IBAction func sliding2(_ sender: Any) {
        let con2 = String(mySlider2.value)
        slidLabel2.text = String(mySlider2.value)

        //SSHConnection("gain="+con2)
        print("exposure="+con2)
    }
    /*func addImageController() {
        addChild(imageController)
        view.addSubview(imageController.view)
    }*/
    @IBAction func closeClicked(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
             
        //该页面显示时强制横屏显示
        appDelegate?.interfaceOrientations = [.landscapeLeft, .landscapeRight]
    }
         
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
             
        //页面退出时还原强制竖屏状态
        appDelegate?.interfaceOrientations = .portrait
  
    }

}





