//
//  ImageController.swift
//  Spiri
//
//  Created by TongHe on 2021-03-15.
//

import UIKit
import Parse
import WebKit

class FirstImage: UIViewController, WKUIDelegate, WKNavigationDelegate {
    let appDelegate: AppDelegate? = UIApplication.shared.delegate as? AppDelegate
    //@IBOutlet var webView: WKWebView!
    var webView: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // loading URL :
        let myBlog = "http://192.168.1.7:8080"
        let url = NSURL(string: myBlog)
        let request = NSURLRequest(url: url! as URL)
        
        // init and load request in webview.
        webView = WKWebView(frame: self.view.frame)
        webView.navigationDelegate = self
        webView.load(request as URLRequest)
        self.view.addSubview(webView)
        self.view.sendSubviewToBack(webView)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //MARK:- WKNavigationDelegate

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation:
    WKNavigation!, withError error: Error) {
        print(error.localizedDescription)
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation:
    WKNavigation!) {
        print("Strat to load")
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("finish to load")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
             
        //该页面显示时强制横屏显示
        //appDelegate?.interfaceOrientations = [.landscapeLeft, .landscapeRight]
        appDelegate?.interfaceOrientations = .allButUpsideDown
    }
         
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
             
        //页面退出时还原强制竖屏状态
        appDelegate?.interfaceOrientations = .portrait
    }

}



