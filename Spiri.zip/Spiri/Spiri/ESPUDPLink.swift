//
//  ESPUDPLink.swift
//  Crazyflie client
//
//  Created by fanbaoying on 2020/4/29.
//  Copyright © 2020 Bitcraze. All rights reserved.
//

import UIKit
import CocoaAsyncSocket
import AFNetworking

class ESPUDPLink: NSObject, CrtpDriver, GCDAsyncUdpSocketDelegate, StreamDelegate {

    let addr = "192.168.1.7"
    let port = 9876
    var inStream : InputStream?
    var outStream: OutputStream?
    
    var buffer = [UInt8](repeating: 0, count: 200)
    
    
    
    var clientSocket: GCDAsyncUdpSocket = GCDAsyncUdpSocket()
    var mainQueue = DispatchQueue.main
    var udpError: String?
    let appPort:UInt16 = 2399
    let devicePort:UInt16 = 2390
    let udpHost = "192.168.43.42"
    var stateCallback: ((NSString) -> ())?
    fileprivate var connectCallback: ((Bool) -> ())?
    fileprivate var state = "idle" {
        didSet {
            stateCallback?(state as NSString)
        }
    }
    override init() {
        super.init()
        clientSocket = GCDAsyncUdpSocket(delegate: self, delegateQueue: mainQueue)
        do {
            try clientSocket.enableBroadcast(true)
            try clientSocket.bind(toPort: appPort, interface: udpError)
            if (udpError != nil) {
                print("error: \(String(describing: udpError))")
            } else {
                try clientSocket.beginReceiving()
            }
        } catch {
            print("catch:\(String(describing: udpError))")
        }
        state = "idle"
    }
    
    func NetworkEnable() {
       
       print("NetworkEnable")
       print(Stream.Event())
       Stream.getStreamsToHost(withName: addr, port: port, inputStream: &inStream, outputStream: &outStream)
       
       inStream?.delegate = self
       outStream?.delegate = self
       
       inStream?.schedule(in: RunLoop.current, forMode: RunLoop.Mode.default)
       outStream?.schedule(in: RunLoop.current, forMode: RunLoop.Mode.default)
       
       inStream?.open()
       outStream?.open()
       buffer = [UInt8](repeating: 0, count: 200)
        
   }
   func btniPhonePressed(_ roll:Float, pitch:Float, thrust:Float, yaw:Float) {
        
       // let data  = "This".data(using: String.Encoding.utf8)! as NSData
       // let string = "Testing stream"
       // let data = string.data(using: String.Encoding.utf8)!
       // _ = data.withUnsafeBytes{ $0.load( outStream?.write($0, maxLength: data.count)) }
        //outStream?.write($0, maxLength: data.length)
        //let string = "1"
        //let f = -33.861382
        let string = "Roll:"+String(format: "%.2f",roll)+" "+"Pitch:"+String(format: "%.2f",pitch)+" "+"Yaw:"+String(format: "%.2f",yaw)+" "+"Thrust:"+String(format: "%.2f",thrust)
        outStream?.write(string, maxLength: string.utf8.count)
        //print(Stream.Event())
        inStream!.read(&buffer, maxLength: buffer.count)
        let bufferStr = NSString(bytes: &buffer, length: buffer.count, encoding: String.Encoding.utf8.rawValue)
        //label.text = bufferStr! as String
        print(bufferStr!)
    }
    func Quit() {
         let string = "Quit"
         outStream?.write(string, maxLength: string.utf8.count)
     }
    
    func udpSocket(_ sock: GCDAsyncUdpSocket, didReceive data: Data, fromAddress address: Data, withFilterContext filterContext: Any?) {
        let recv = NSString(data: data, encoding: String.Encoding.utf8.rawValue)
        let showStr: NSMutableString = NSMutableString()
        showStr.append(recv! as String)
        showStr.append("\n")
        print("didReceive: \(String(describing: recv))")
    }
    func udpSocket(_ sock: GCDAsyncUdpSocket, didNotConnect error: Error?) {
        print("Connection failed: \(String(describing: error))")
    }
    func udpSocket(_ sock: GCDAsyncUdpSocket, didSendDataWithTag tag: Int) {
        print("Data has been sent: \(tag)")
    }
    func udpSocketDidClose(_ sock: GCDAsyncUdpSocket, withError error: Error?) {
        print("Disconnect error: \(String(describing: error))")
    }
    func udpSocket(_ sock: GCDAsyncUdpSocket, didConnectToAddress address: Data) {
        print("Start connecting")
    }
    func connect(_ address: String?, callback: @escaping (Bool) -> ()) {
        print("ESPUDPLink connect")
        //网络状态消息监听
        NotificationCenter.default.addObserver(self, selector: #selector(sendWifiStatus), name: NSNotification.Name.AFNetworkingReachabilityDidChange, object: nil)
        //开启网络状态消息监听
        AFNetworkReachabilityManager.shared().startMonitoring()
        connectCallback = callback
    }
    @objc func sendWifiStatus() {
        if AFNetworkReachabilityManager.shared().isReachable {
            if AFNetworkReachabilityManager.shared().isReachableViaWiFi {
                print("Connection Type：WiFi")
                state = "connected"
                connectCallback?(true)
            } else if AFNetworkReachabilityManager.shared().isReachableViaWWAN {
                print("Connection Type：mobile network")
                connectCallback?(false)
            }
        } else {
            print("Connection Type：No internet connection")
            connectCallback?(false)
        }
    }
    func disconnect() {
        print("Remove message notification")
        state = "idle"
        //关闭网络状态消息监听
        AFNetworkReachabilityManager.shared().stopMonitoring()
        //移除网络状态消息通知
        NotificationCenter.default.removeObserver(self)
    }
    
    func sendPacket(_ packet: Data, callback: ((Bool) -> ())?) {
//        print("ESPUDPLink send UDP data: \(packet)")
        clientSocket.send(packet, toHost: udpHost, port: devicePort, withTimeout: -1, tag: 0)
    }
    
    func onStateUpdated(_ callback: @escaping (NSString) -> ()) {
        stateCallback = callback
    }
}
