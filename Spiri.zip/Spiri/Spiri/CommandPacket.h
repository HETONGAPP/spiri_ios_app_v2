//
//  CommandPacket.h
//  Spiri
//
//  Created by TongHe on 2021-03-11.
//

#import <Foundation/Foundation.h>

typedef struct __attribute__((packed)) {
    uint8_t header;
    float roll;
    float pitch;
    float yaw;
    uint16_t thrust;
} CommanderPacket;

@interface CommandPacketCreator : NSObject

+ (NSData *)dataFrom:(CommanderPacket) packet;

@end

